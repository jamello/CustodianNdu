﻿
Partial Class NEW_TBL
    Inherits System.Web.UI.Page

End Class
